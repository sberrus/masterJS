import React from "react";
import "bootstrap/dist/js/bootstrap.min.js";

const Footer = () => {
    return <div className="mt-5 border-top text-center py-3">FOOTER</div>;
};

export default Footer;
